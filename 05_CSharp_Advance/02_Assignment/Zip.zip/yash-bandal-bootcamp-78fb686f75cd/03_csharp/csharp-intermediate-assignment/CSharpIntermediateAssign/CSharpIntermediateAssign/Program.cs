﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using CSharpIntermediateAssign.Interface;

namespace CSharpIntermediateAssign
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Select Calculator");
            Console.WriteLine("1. Basic Calculator (Default selection)");
            Console.WriteLine("2. Advanced Calculator");

            Console.WriteLine();

            Console.WriteLine("Enter your choice");
            string ch = Console.ReadLine().Trim();

            ICalculator calculator;

            if (ch == "2")
            {
                calculator = new AdvancedCalculator();
            }
            else
            {
                calculator = new Calculator();
            }

            while (true)
            {
                Console.WriteLine("\n===== Calculator Menu =====");
                Console.WriteLine("1. Add 2 Integers");
                Console.WriteLine("2. Add 3 Integers");
                Console.WriteLine("3. Add 2 Floating Point Numbers");

                if (calculator is IAdvancedCalculator)
                {
                    Console.WriteLine("4. Power");
                }
                /*
                 This checks if object currently stored inside 'calculator' var implements IAdvanceCalculator
                 */

                Console.WriteLine("5. Get Result");
                Console.WriteLine("0. Exit");

                Console.Write("\nEnter your choice: ");
                string choice = Console.ReadLine().Trim();

                switch (choice)
                {
                    case "1":
                    {
                        Console.Write("Enter first integer: ");
                        if (!int.TryParse(Console.ReadLine(), out int num1))
                        {
                            Console.WriteLine("Invalid first integer.");
                            break;
                        }

                        Console.Write("Enter second integer: ");
                        if (!int.TryParse(Console.ReadLine(), out int num2))
                        {
                            Console.WriteLine("Invalid second integer.");
                            break;
                        }

                        Console.WriteLine($"Result = {calculator.Add(num1, num2)}");
                        break;
                    }

                    case "2":
                    {
                        Console.Write("Enter first integer: ");
                        if (!int.TryParse(Console.ReadLine(), out int num1))
                        {
                            Console.WriteLine("Invalid first integer.");
                            break;
                        }

                        Console.Write("Enter second integer: ");
                        if (!int.TryParse(Console.ReadLine(), out int num2))
                        {
                            Console.WriteLine("Invalid second integer.");
                            break;
                        }

                        Console.Write("Enter third integer: ");
                        if (!int.TryParse(Console.ReadLine(), out int num3))
                        {
                            Console.WriteLine("Invalid third integer.");
                            break;
                        }

                        Console.WriteLine($"Result = {calculator.Add(num1, num2, num3)}");
                        break;
                    }

                    case "3":
                    {
                        Console.Write("Enter first number: ");
                        if (!float.TryParse(Console.ReadLine(), out float num1))
                        {
                            Console.WriteLine("Invalid first number.");
                            break;
                        }

                        Console.Write("Enter second number: ");
                        if (!float.TryParse(Console.ReadLine(), out float num2))
                        {
                            Console.WriteLine("Invalid second number.");
                            break;
                        }

                        Console.WriteLine($"Result = {calculator.Add(num1, num2)}");
                        break;
                    }

                    case "4":
                    {
                        if (calculator is IAdvancedCalculator advancedCalculator)
                        {
                            Console.Write("Enter base: ");
                            if (!int.TryParse(Console.ReadLine(), out int baseNum))
                            {
                                Console.WriteLine("Invalid base.");
                                break;
                            }

                            Console.Write("Enter exponent: ");
                            if (!int.TryParse(Console.ReadLine(), out int exponent))
                            {
                                Console.WriteLine("Invalid exponent.");
                                break;
                            }

                            Console.WriteLine($"Result = {advancedCalculator.Power(baseNum, exponent)}");
                        }
                        else
                        {
                            Console.WriteLine("Power Application is only applicable for Advance Calculator");
                        }
                        break;
                    }

                    case "5":
                    {
                        Console.WriteLine($"Latest Result  = {calculator.GetResult()}");
                        break;
                    }

                    case "0":
                    {
                        Console.WriteLine("Exiting..");
                        return;
                    }

                    default:
                    {
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                    }
                }
            }
        }
    }
}
