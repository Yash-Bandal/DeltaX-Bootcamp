﻿namespace CSharpIntermediateAssign.Interface
{
    public interface ICalculator
    {
        int Add(int num1, int num2);
        int Add(int num1, int num2, int num3);
        float Add(float fnum1, float fnum2);
        double GetResult();
    }
}
