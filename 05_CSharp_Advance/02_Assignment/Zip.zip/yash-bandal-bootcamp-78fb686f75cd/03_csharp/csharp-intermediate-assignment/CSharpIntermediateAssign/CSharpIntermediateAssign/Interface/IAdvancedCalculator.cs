﻿
namespace CSharpIntermediateAssign.Interface
{
    public interface IAdvancedCalculator : ICalculator
    {
        double Power(int baseNum, int exponent);  
    }
}
